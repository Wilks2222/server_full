package www

import (
	"crypto/tls"
	"github.com/NYTimes/gziphandler"
	"github.com/antigloss/go/logger"
	"github.com/gorilla/mux"
	"net/http"
	"strconv"
)

/* Start to listen for request on HTTP the handler will respond too three type
   if request:  /get for reading data from the database, /post for saving
   data into the database and all other request will be redirected to
   the public folder to see if a static file can be served.
   ONLY HTTPS is supported optionally it's possible to enabled HTTP redirection.
*/

func Start(listenIP string, listenPort int, redirectHTTP bool, certificate, key string) {

	router := mux.NewRouter()

	if redirectHTTP {
		logger.Info("Starting the HTTP Redirection to " + "https://" + listenIP + ":" + strconv.Itoa(listenPort))
		go http.ListenAndServe(":80", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			http.Redirect(w, r, "https://"+r.Host+":"+strconv.Itoa(listenPort)+r.URL.String(), http.StatusMovedPermanently)
		}))
	}
	/*
		router.HandleFunc("/get", getData).Methods("POST")

		// rate limit those below request!!
		router.HandleFunc("/post", putData).Methods("POST")
		router.HandleFunc("/log", getlogData).Methods("POST")
		router.HandleFunc("/backup", doBackup).Methods("POST")
		router.HandleFunc("/getbackup/{file}", getBackup).Methods("GET")

		router.HandleFunc("/login", login).Methods("POST")

		router.HandleFunc("/dkmsdelete", DKMSDelete).Methods("POST")
		router.HandleFunc("/dkmscomment", putDKMSComment).Methods("POST")
		router.HandleFunc("/dkmsplay", putDKMSPlay).Methods("POST")
		router.HandleFunc("/dkmssearch", getDKMSSearch).Methods("POST")
		router.HandleFunc("/dkmsgetplay", getDKMSPlay).Methods("POST")
		router.HandleFunc("/dkmsgetplaybycategory", getDKMSPlayByCategory).Methods("POST")

		router.HandleFunc("/dkmsdownloadplay", getDKMSDownload).Methods("POST")
		router.HandleFunc("/playbook/{file}", getDKMSDownloadFile).Methods("GET")
		router.HandleFunc("/dkmsupload", putDKMSUpload).Methods("POST")

		router.HandleFunc("/wss", func(w http.ResponseWriter, r *http.Request) {
			websocket.ServeWs(w, r)
		})
	*/

	router.PathPrefix("/").Handler(http.FileServer(http.Dir("www/public")))

	logger.Info("Starting the HTTPS server on " + listenIP + ":" + strconv.Itoa(listenPort))

	cfg := &tls.Config{
		InsecureSkipVerify:       true,
		MinVersion:               tls.VersionTLS12,
		CurvePreferences:         []tls.CurveID{tls.CurveP521, tls.CurveP384, tls.CurveP256},
		PreferServerCipherSuites: true,
		CipherSuites: []uint16{
			tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA,
			tls.TLS_RSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_RSA_WITH_AES_256_CBC_SHA,
			tls.TLS_RSA_WITH_RC4_128_SHA,
			tls.TLS_RSA_WITH_3DES_EDE_CBC_SHA,
			tls.TLS_RSA_WITH_AES_128_CBC_SHA,
			tls.TLS_RSA_WITH_AES_256_CBC_SHA,
			tls.TLS_ECDHE_ECDSA_WITH_RC4_128_SHA,
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA,
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA,
			tls.TLS_ECDHE_RSA_WITH_RC4_128_SHA,
			tls.TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA,
			tls.TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA,
			tls.TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA,
			tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
		},
	}

	srv := &http.Server{
		//ErrorLog:     logging.New(&customLogger{logger}, "", 0),
		Addr:         listenIP + ":" + strconv.Itoa(listenPort),
		Handler:      gziphandler.GzipHandler(router),
		TLSConfig:    cfg,
		TLSNextProto: make(map[string]func(*http.Server, *tls.Conn, http.Handler), 0),
	}

	srv.ListenAndServeTLS(certificate, key)

}
