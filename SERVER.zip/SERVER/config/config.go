/*
Config Package
*/

package config

import (
	"encoding/json"
	"errors"
	"github.com/antigloss/go/logger"
	"io/ioutil"
	"os"
)

/* Configuration details
 */

/* The following status are use by the GUARD
 */
const StatusUP = 100
const StatusJEOPARDY = 75
const StatusDEGRADATION = 25
const StatusMAINTENANCE = 15
const StatusUNKNOWN = 2
const StatusUNREACHABLE = 1
const StatusDOWN = 0

type ConfigItem struct {

	/* Serve the Database thru a TCP API, this API for security purposes should only listen to localHost. User must send an ID follow by CRLF and the
	   API will response with the device status or not respond if ID is unknown.
	*/
	TCPAPIListenIP string `json:"tcpapilistenip"` // = "127.0.0.1:3333"
	ServerIP       string `json:"serverip"`

	/* Listen for packet from the GUARD on this address with that many threads
	 */
	UDPListenIP            string `json:"udplistenip"`            // = "127.0.0.1" // replace with the IP of the GUARD network x.x.x.x/30
	UDPListenPort          int    `json:"udplistenport"`          //= 512
	NumOfUDPQueueThread    int    `json:"numofudpqueuethread"`    //= 8       // number of threads to create to process the UDP packets.
	UDPReceiverChannelSize int    `json:"udpreceiverchannelsize"` //= 4096 // a Channel is use to concurrently process packet received.

	/* Database information.
	 */
	DatabaseFileName    string `json:"databasefilename"`    //= "owlso.db"
	DatabaseChannelSize int    `json:"databasechannelsize"` //= 4096 // cache channel size to write to the database

	/* Log file information.
	 */
	LogFolder      string `json:"logfolder"`      //= "./log"
	DeleteLogFiles int    `json:"deletelogfiles"` //= 20
	MaxLogFiles    int    `json:"maxlogfiles"`    //= 300
	MaxSizeLogFile uint32 `json:"maxsizelogfile"` //= 1
	ShowTrace      bool   `json:"showtrace"`      //= true
	MaxLogsItem    int    `json:"maxlogitem"`     //= 30 // for UI

	/* This is the number of threads that will listen for request against the TCP API
	   it will require experience to improve this number and it will depend on how
	   many simulteanous connection InterMapper will open against the TCP API.
	*/
	HandleConnectionThreads int `json:"handleconnectionthreads"` // = 64

	/* Connectivity details about InterMapper, this is required because every time
	   we receive a new item, a new probe will be imported in InterMapper in a
	   specific page that store newly detected probes.
	*/
	PostToInterMapper   bool   `json:"posttointermapper"`   // true
	InterMapperMaxDelay int    `json:"intermappermaxdelay"` //= 300 // delay between scan if no items need to be send
	InterMapperMinDelay int    `json:"intermappermindelay"` //= 5   // delay between creation of items
	InterMapperAddress  string `json:"intermapperaddress"`  //= "127.0.0.1"
	InterMapperPort     int    `json:"intermapperport"`     //= 8181
	InterMapperUsername string `json:"intermapperusername"` //= "admin"
	InterMapperPassword string `json:"intermapperpassword"` //= "12345"
	InterMapperPage     string `json:"intermapperpage"`     // = "Discovered Probes"

	BackupPath        string `json:"backuppath"`
	BackupIntervalHrs int    `json:"backupintervalhrs"`
}

func GetStatusTxt(status int) string {
	switch status {
	case StatusUP:
		return "UP"
	case StatusJEOPARDY:
		return "JEOPARDY"
	case StatusDEGRADATION:
		return "DEGRADATION"
	case StatusMAINTENANCE:
		return "MAINTENANCE"
	case StatusUNREACHABLE:
		return "UNREACHABLE"
	case StatusDOWN:
		return "DOWN"
	}
	return "UNKNOWN"
}

/* load configuration from file, if the username and password for the
   systems are in clear, the configuration will be encrypted and the
   configuration file will be rewritten.
*/

func Load(filename string, data *ConfigItem) error {

	/* check if file exists
	 */
	if _, err := os.Stat(filename); os.IsNotExist(err) {
		return errors.New("File does not exists " + filename)
	}

	logger.Info("loading configuration...")

	/* read configuration into a byte slice
	 */
	file, err := ioutil.ReadFile(filename)
	if err != nil {
		return err
	}

	/* convert the JSON string (configuration format) into the struct that
	   will be holding it into RAM
	*/
	err = json.Unmarshal([]byte(file), &data)
	if err != nil {
		return err
	}

	/* Here every username and password are encrypted... decrypted them on demande only when the
	   monitoring thread need to be executed.
	*/

	return nil
}
