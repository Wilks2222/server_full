package database

import (
	"github.com/antigloss/go/logger"
	"github.com/marcgauthier/server/config"
	"github.com/vmihailenco/msgpack/v4"
	"strconv"
	"strings"
	"sync"
	"time"
)

/* maps for holding the probes (PROBES and QUERIES) status into memory
 */
var probes map[string]*Probe // map is allocated in the database initialize function.

var mutexProbes = &sync.RWMutex{}

type Probe struct {
	/* bellow is data received by broadcaster, the broadcaster might send more information
	   but this is what we need everything else is extra and does not need to be sent to
	   couchdb, remember the application-server should only update the status of probes
	   and queries.  Those need to be manually define in the CouchDB by the client application.
	*/
	ID            string `msgpack:"id" json:"id"`                       // need to be "IP+HOSTNAME+NETWORK+REPORTINGTOOL"
	GuardID       string `msgpack:"guardid" json:"guardid"`             // GuardID ToolUniqueID + Reportingtool + Network
	Status        int    `msgpack:"status" json:"status"`               //
	UpdateTime    int64  `msgpack:"updatetime" json:"updatetime"`       // this change if data is change locally or remotly
	Reportingtool string `msgpack:"reportingtool" json:"reportingtool"` //
	Type          string `msgpack:"type" json:"type"`                   // PROBE or QUERY
	Statussince   int64  `msgpack:"statussince,omitempty" json:"statussince,omitempty"`
	Location      string `msgpack:"location,omitempty" json:"location,omitempty"`

	// Internal info
	AddedToInterMapper bool `msgpack:"addedtointermapper,omitempty" json:"addedtointermapper"` // true if item is in intermapper already
	/*
		below properties are only used if Type="PROBE" and ommited for "QUERY"
	*/
	Network  string `msgpack:"network,omitempty" json:"network,omitempty"`
	IP       string `msgpack:"ip,omitempty" json:"ip,omitempty"`
	Hostname string `msgpack:"hostname,omitempty" json:"hostname,omitempty"`
}

var pool = sync.Pool{
	// New creates an object when the pool has nothing available to return.
	// New must return an interface{} to make it flexible. You have to cast
	// your type after getting it.
	New: func() interface{} {
		// Pools often contain things like *bytes.Buffer, which are
		// temporary and re-usable.
		return &Probe{}
	},
}

/* get one item from the pool, item will be allocated but field Buffer len will be zero
 */
func getItemFromPool() *Probe {
	return pool.Get().(*Probe)
}

/* put back one item in the pool, clear the buffer that will no longer be use
 */
func putItemInPool(i *Probe) {
	// keep the .Buffer property so it can be reused later.
	pool.Put(i)
}

/* Update the fields of an old probe with the content of a new probe
 */
func update(oldP, newP *Probe, insert bool) {

	if insert {
		oldP.ID = newP.ID
		oldP.GuardID = newP.GuardID
		oldP.Statussince = time.Now().Unix()
		oldP.AddedToInterMapper = false
	} else if oldP.Status != newP.Status {
		oldP.Statussince = time.Now().Unix()
	}
	oldP.UpdateTime = newP.UpdateTime
	oldP.Status = newP.Status
	oldP.Reportingtool = newP.Reportingtool
	oldP.Type = newP.Type
	if newP.Type == "PROBE" {
		oldP.Network = newP.Network
		oldP.IP = newP.IP
		oldP.Hostname = newP.Hostname
	}

}

/* Convert the const number for a status into it's text code
 */

func GetStatusTxt(status int) string {
	switch status {
	case config.StatusUP:
		return "UP" //up
	case config.StatusJEOPARDY:
		return "Jeopardy" // jeopardy
	case config.StatusDEGRADATION:
		return "Degradation" // degradation
	case config.StatusMAINTENANCE:
		return "Maintenance" // maintenance
	case config.StatusUNKNOWN:
		return "Unknown" //
	case config.StatusUNREACHABLE:
		return "Unreachable" // Unreachable
	case config.StatusDOWN:
		return "Down" // down
	default:
		return "Unknown" // unknow
	}
}

/*
	Receive a Probe from the collector check if probe exists if not insert probe
	if exists check if UpdateTime is > existing data
*/

func Receive(data []byte) {

	// infinite loop reading packet and processing

	RxProbe := &Probe{}

	if err := msgpack.Unmarshal(data, &RxProbe); err != nil {
		logger.Error(err.Error() + " // " + string(data))
		return
	}

	RxProbe.Type = strings.ToUpper(RxProbe.Type)

	mutexProbes.Lock()
	defer mutexProbes.Unlock()

	/* verify if probe or query already exists
	 */
	if probe, ok := probes[RxProbe.GuardID]; ok {

		/* probe or query exists check if this is a rebroadcast (duplicate) or if this is actually new info!
		   the updatetime is save in nano second so the chance that status change
		*/
		if RxProbe.UpdateTime > probe.UpdateTime {

			switch RxProbe.Type {
			case "PROBE":
				logger.Trace("update Probe ip=" + RxProbe.IP + " host=" + RxProbe.Hostname + " network=" + RxProbe.Network + " status=" + strconv.Itoa(RxProbe.Status) + " tool=" + RxProbe.Reportingtool)
			case "QUERY":
				logger.Trace("update Query id=" + RxProbe.ID + " status=" + strconv.Itoa(RxProbe.Status))
			}

			update(probe, RxProbe, false)

			/* Send a Copy not a pointer of the probe to the writting channel.
			 */
			WriteToDB <- probe

		}

		return
	}

	/* could not find the probe insert new packet into the memory map, first create the object.
	 */

	switch RxProbe.Type {
	case "PROBE":
		logger.Trace("insert Probe ip=" + RxProbe.IP + " host=" + RxProbe.Hostname + " network=" + RxProbe.Network + " status=" + strconv.Itoa(RxProbe.Status) + " tool=" + RxProbe.Reportingtool)
	case "QUERY":
		logger.Trace("insert Query id=" + RxProbe.ID + " status=" + strconv.Itoa(RxProbe.Status))
	}

	p := getItemFromPool()

	update(p, RxProbe, true)

	/* save object in memory map
	 */
	probes[p.GuardID] = p

	/* Send a pointer of the probe to the writting channel.
	 */
	WriteToDB <- p

}
