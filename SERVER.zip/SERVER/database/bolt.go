package database

import (
	"encoding/json"
	"errors"
	"github.com/antigloss/go/logger"
	"github.com/marcgauthier/server/config"
	"github.com/marcgauthier/server/intermapper"
	bolt "go.etcd.io/bbolt"
	"os"
	"strconv"
	"time"
)

/* channel use to create a cache for writing data to boltDB.
 */
var WriteToDB chan *Probe

/* Database object
 */
var db *bolt.DB

/* This function allocate memory for the maps and channel and open the file that contains
   the database.
*/
func Initialized(filename string, channelSize int, PostToInterMapper bool, InterMapperMaxDelay, InterMapperMinDelay int,
	InterMapperPage, InterMapperAddress, InterMapperUsername, InterMapperPassword, ServerIP string, InterMapperPort int, backupPath string, backupIntervalHrs int) {

	logger.Info("Initializating memory maps and database channels")

	probes = make(map[string]*Probe)

	WriteToDB = make(chan *Probe, channelSize)

	var err error

	logger.Info("Opening " + filename)

	/*  Open the connection to the database.
	 */
	db, err = bolt.Open(filename, 0600, nil)
	if err != nil {
		logger.Error(err.Error())
		os.Exit(1)
	}

	// load all items into memory
	err = loadAllProbes()
	if err != nil {
		logger.Error(err.Error())
	}

	/* Monitor probe to find new ones and add them to InterMapper Discovered Probes, if
	   no new items are found take a longer pause default to 5 mins, if there are
	   an items take a short pause then send another item to InterMapper.
	*/
	if PostToInterMapper {
		go WriteNewProbeToIntermapper(InterMapperMaxDelay, InterMapperMinDelay, InterMapperPage, InterMapperAddress, InterMapperUsername, InterMapperPassword, ServerIP, InterMapperPort)
	}

	go WriteChangesToDisk()

	go backupDB(backupPath, backupIntervalHrs)
}

func backupDB(path string, intervalHrs int) {

	/* create folder for storing log files if it does not already exists.
	 */
	if _, err := os.Stat(path); os.IsNotExist(err) {
		os.Mkdir(path, os.ModeDir)
	}

	for {
		time.Sleep(time.Hour * time.Duration(intervalHrs))

		filename := path + "/" + time.Now().Format("20060102150405")

		err := db.View(func(tx *bolt.Tx) error {
			return tx.CopyFile(filename, 0600)
		})
		if err != nil {
			logger.Error(err.Error())
		}
	}

}

/* Monitor probe to find new ones and add them to InterMapper Discovered Probes, if
   no new items are found take a longer pause default to 5 mins, if there are
   an items take a short pause then send another item to InterMapper.
*/
func WriteNewProbeToIntermapper(InterMapperMaxDelay, InterMapperMinDelay int, InterMapperPage, InterMapperAddress, InterMapperUsername, InterMapperPassword, ServerIP string, InterMapperPort int) {

	for {
		ProbeID := ""
		ProbeName := ""
		/* Find next items to add to Intermapper
		 */
		mutexProbes.RLock()
		for key, p := range probes {
			if !p.AddedToInterMapper {
				/* These two information will be send to InterMapper, the ProbeID is use to contact the
				   TCP-API and the ProbeName is the label to display the probe on InterMapper.
				*/
				ProbeID = key
				ProbeName = p.Network + "-" + p.IP + "-" + p.Hostname + "-" + p.Reportingtool
				break
			}
		}
		mutexProbes.RUnlock()

		/* If no items were found sleep for 5 minutes, otherwise sleep for 5 second
		 */
		if ProbeID == "" {
			time.Sleep(time.Duration(InterMapperMaxDelay) * time.Second)
		} else {
			time.Sleep(time.Duration(InterMapperMinDelay) * time.Second)
		}

		/* Try to add this item into InterMapper
		 */
		if intermapper.CreateProbe(ProbeID, ProbeName, InterMapperPage, InterMapperAddress, InterMapperUsername, InterMapperPassword,
			ServerIP, InterMapperPort) {
			// success save the item status
			mutexProbes.Lock()
			if p, ok := probes[ProbeID]; ok {
				p.AddedToInterMapper = true
				// get memory clone item and send it to the channel for writting.
				// do not send the p pointer otherwise the write function
				// will need to do a lock()
				q := getItemFromPool()
				*q = *p
				WriteToDB <- q
			}
			mutexProbes.Unlock()
		}

	}
}

/* load all probes from the bolt database into a memory map
 */
func loadAllProbes() error {

	// load all probes from database in memory
	mutexProbes.Lock()
	defer mutexProbes.Unlock()

	err := db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte("PROBES"))
		if b != nil {
			b.ForEach(func(k, v []byte) error {
				probe := Probe{}
				if err := json.Unmarshal(v, &probe); err == nil {
					probes[probe.ID] = &probe
				} else {
					logger.Error(err.Error())
				}
				return nil
			})
		}
		return nil
	})
	return err
}

/* Write the status of one item into the couchDB Database, in case there is
   a connection lost this function you initiate a call to connectCouchDB.
   This function does not support concurrency and can only be called once at
   a time.
   The cache revision work because this application is the only one writing
   status in the database.  WEB Client are only reading the status not
   changing it.
*/

func WriteChangesToDisk() {
	/*  Monitor the WriteToDB channel to see what item need to be
	saved to db. Item`s are struct probe.
	*/
	for item := range WriteToDB {

		logger.Trace("Saving to disk probe " + item.ID + " status " + strconv.Itoa(item.Status) + " to DB")

		err := db.Update(func(tx *bolt.Tx) error {

			b, err := tx.CreateBucketIfNotExists([]byte("PROBES"))
			if err != nil {
				return err
			}

			// Marshal probe data into bytes.
			buf, err := json.Marshal(item)
			if err != nil {
				return err
			}

			// Persist bytes to bucket.
			return b.Put([]byte(item.ID), buf)

		})

		if err != nil {
			logger.Error(err.Error())
		}
		putItemInPool(item)
	}

}

/* This function will look for a probe and return it's status or err if the
   probe is not found.  This function support the TCP-API for Intermapper
   to get the values of probes.
*/
func GetStatus(ID []byte) (int, error) {

	var result int

	if len(ID) > 0 {
		mutexProbes.RLock()
		defer mutexProbes.RUnlock()

		/* verify if probe or query already exists
		 */
		if p, ok := probes[string(ID)]; ok {
			result = p.Status
			return result, nil
		}
	}
	return config.StatusUNKNOWN, errors.New("NotFound")

}
