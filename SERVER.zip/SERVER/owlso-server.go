/*
_____________________________________________________________________________________


OWLSO-APPLICATION-SERVER:

	The OWLSO-Server: role is to receive probe and query status from the GUARD, and store this information locally
	into a BoltDB file.

	InterMapper will be installed on the network and do request to the TCP-API.  InterMapper will be use
	to display network device status and Queries status


	InterMapper Servers Standard > Custom TCP
		This probe sends the specified string over a TCP connection, and sets the
		status of the device based on the response. Six parameters control the
		operation of this probe:
		String to send - The initial string sent to the device via TCP. This could be
		a command which indicates what to test, or a combination of a command
		and a password. The string is sent on its own line, terminated by a CRLF.
		Seconds to wait - The number of seconds to wait for a response. If no
		response is received within the specified number of seconds, the
		device's status is set to Down.
		- 506 -
		Chapter 13: Probe Reference
		OK Response - The substring to match the device's "ok response". If it
		matches the first line received, the device is reported to have a status of
		OK.
		WARN Response - The substring to match the device's Warning
		response.
		ALRM Response - The substring to match the device's Alarm response.
		CRIT Response - The substring to match the device's Critical response.
		DOWN Response - The substring to match the device's Down response.
		If InterMapper cannot connect to the specified TCP port, the device's
		status is set to Down


	Dependencies:
		"github.com/antigloss/go/logger"	; log activity on disk
		bolt "go.etcd.io/bbolt"				; database library

	statusUP			= 100	= OK
	statusJEOPARDY		= 75	= CRITICAL
	statusDEGRADATION	= 25	= ALARM
	statusMAINTENANCE	= 15	= WARN
	statusUNKNOWN		= 2		= DOWN
	statusUNREACHABLE	= 1		= DOWN
	statusDOWN			= 0		= DOWN


    Network + RepportingTool + ID   // This way Device or Service can be found!

    If two monitoring tool are monitoring the same device it does not matter manually in the InterMapper we will either create two item i.e
    itemA monitor by WUG and itemA (same) monitor by InterMapper etc.

	InterMapper must have a map called "Discovered Probes" where all the new probes will be created.

	TCI-API is served on port 3333 localHost. Default, this can be customize in Config.go


_____________________________________________________________________________________

*/

package main

import (
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/antigloss/go/logger"
	"github.com/marcgauthier/receiver"
	"github.com/marcgauthier/server/api"
	"github.com/marcgauthier/server/config"
	"github.com/marcgauthier/server/database"
	"github.com/marcgauthier/server/www"
)

/*
	Main function of the program.
*/

func main() {

	/* Ask for a password on the input to decrypt configuration and load configuration file.
	 */
	Config := config.ConfigItem{}
	err := config.Load("owlso-server.conf", &Config)
	if err != nil {
		fmt.Println("Unable to read config file " + err.Error())
		os.Exit(1)
		return
	}

	/* create folder for storing log files if it does not already exists.
	 */
	if _, err := os.Stat(Config.LogFolder); os.IsNotExist(err) {
		os.Mkdir(Config.LogFolder, os.ModeDir)
	}

	/* logger options are Trace, Info, Warn, Error, Panic and Abort
	   logs are saved into the log/ folder
	*/

	logger.Init(&logger.Config{
		LogDir:          Config.LogFolder,
		LogFileMaxSize:  Config.MaxSizeLogFile,
		LogFileMaxNum:   Config.MaxLogFiles,
		LogFileNumToDel: Config.DeleteLogFiles,
		LogLevel:        logger.LogLevelInfo,
		LogDest:         logger.LogDestBoth,
		Flag:            logger.ControlFlagLogLineNum,
	})

	/* Log are sent to file, optionally can be sent on the display, currently disabled because
	   we are using loggy package instead to display logs on the screen.
	*/
	//logger.SetLogToConsole(true)

	/* Open the database and read probes into the memory cache
	 */
	database.Initialized(Config.DatabaseFileName, Config.DatabaseChannelSize, Config.PostToInterMapper, Config.InterMapperMaxDelay, Config.InterMapperMinDelay,
		Config.InterMapperPage, Config.InterMapperAddress, Config.InterMapperUsername, Config.InterMapperPassword, Config.ServerIP, Config.InterMapperPort,
		Config.BackupPath, Config.BackupIntervalHrs)

	/* Serve HTML and Javascript file over HTTPS (Port443) Database will be serve on HTTPS Port 8443
	 */
	logger.Info("Starting the TCP API resPonding to request on " + Config.TCPAPIListenIP)

	go api.Start(Config.TCPAPIListenIP, Config.HandleConnectionThreads)

	/* start the receiver that receive from the RELAY's
	 */
	receiver.Start(Config.UDPListenIP, Config.UDPListenPort, Config.NumOfUDPQueueThread, func(data []byte) {
		database.Receive(data)
	})

	// this function does not comeback!
	go www.Start("0.0.0.0", 443, true, "www/server.csr", "www/server.key")

	/* wait for control-C
	 */
	c := make(chan os.Signal)
	signal.Notify(c, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-c
		logger.Info("Cleaning up, closing application.")
		//cleanup()
		os.Exit(1)
	}()

	for {
		time.Sleep(10 * time.Second) // or runtime.Gosched() or similar per @misterbee
	}

	logger.Info("Program stopped with CTRL-C")

	//add a function in probes that scan probes if reporting tool = "RELAY" or "GUARD" then if
	//the updatetime >5mins then set the status = down!

}
