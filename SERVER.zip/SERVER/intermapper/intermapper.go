package intermapper

import (
	"crypto/tls"
	"io/ioutil"
	"net/http"
	"strconv"
	"strings"

	"github.com/antigloss/go/logger"
	"github.com/marcgauthier/server/config"
)

/*
   This function will try to create a new Item into the Discover Probe Page inside InterMapper

    const InterMapperMaxDelay = 300 // delay between scan if no items need to be send
    const InterMapperMinDelay = 5   // delay between creation of items
    const InterMapperAddress = "127.0.0.1"
    const InterMapperPort = 8181
    const InterMapperUsername = "admin"
    const InterMapperPassword = "12345"
    const InterMapperPage = "Discovered Probes"

    POST: https://InterMapperUsername:InterMapperPassword@InterMapperAddress:InterMapperPort/~import/dummyfilename

	ProbeName define the label that will be displayed in InterMapper
	ProbeID is the string that will be sent to the TCP-API to get the probe status.

	ServerIP is the address of the SERVER where the TCP-API can be querry if InterMapper is installed on the
	same server as the OWLSO-SERVER this should be 127.0.0.1
*/
func CreateProbe(probeID, probeName, InterMapperPage, InterMapperAddress, InterMapperUsername, InterMapperPassword, ServerIP string, InterMapperPort int) bool {

	data := "#format=tab table=devices fields=MapName,DNSName,Address,Probe,Name,IMProbe\n" +
		InterMapperPage + "\t" + probeName + "\t" + ServerIP + "\tCustom TCP\t" + probeName + "\t" +
		"improbe://" + InterMapperAddress + ":" + strconv.Itoa(InterMapperPort) + "/com.dartware.tcp.custom?string_to_send=" +
		probeID + "&seconds_to_wait=3" +
		"&ok_response=" + strconv.Itoa(config.StatusUP) +
		"&warn_response=" + strconv.Itoa(config.StatusMAINTENANCE) +
		"&alrm_response=" + strconv.Itoa(config.StatusDEGRADATION) +
		"&crit_response=CRIT" + strconv.Itoa(config.StatusJEOPARDY) +
		"&down_response=" + strconv.Itoa(config.StatusDOWN)

	logger.Trace("creating probe on InterMapper: " + data)

	url := "https://" + InterMapperUsername + ":" + InterMapperPassword + "@" + InterMapperAddress + ":" + strconv.Itoa(InterMapperPort) + "/~import/dummyfilename"

	msg, err := upload(url, data)
	if err != nil {
		logger.Error(err.Error())
		return false
	}

	if len(msg) > 0 {
		logger.Trace("resp from InterMapper: " + string(msg))
	}
	return true
}

func upload(url, data string) ([]byte, error) {

	c := strings.NewReader(data)

	http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true}

	res, err := http.Post(url, "binary/octet-stream", c)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	message, _ := ioutil.ReadAll(res.Body)
	return message, nil
}
